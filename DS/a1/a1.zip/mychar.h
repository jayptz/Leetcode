/*
 * your program signature
 */ 
#ifndef MYCHAR_H
#define MYCHAR_H



/**
 *  add your comment
 */
int mytype(char c);

/**
 *  add your comment
 */
char case_flip(char c);

/**
 *  add your comment
 */
int digit_to_int(char c);

#endif